# NO-ESCAPE
this is a malware created by me called NO ESCAPE!
the wallpaper has the dates to set for payloads!


# THE PASSWORD WHEN LOGGING IN TO YOUR ACCOUNT IS death AS in No Escape
# TRY KILLING THE PROCESS :D
